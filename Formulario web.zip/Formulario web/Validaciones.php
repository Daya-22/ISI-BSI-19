﻿<?php

if( isset($_POST['Usuario'])&& isset($_POST['Pass'])&& isset($_POST['Correo'])&& isset($_POST['Fecha_Nacimiento']))
{
    $Correo = $_POST["Correo"];
}

function validarCorreo($Correo)
{
    if(preg_match("^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$", $Correo)){
    echo ("Correo correcto");
    } else {
    return false;
    }
}

?>