<?php
session_start();
$Nombre = $_POST['Nombre'];
$Direccion = $_POST['Direccion'];
$Horario = $_POST['Horario'];
$Genero = $_POST['gen'];
$Materias = $_POST['mt'];
$Edad = $_POST['Edad'];

echo($Nombre);
echo($Direccion);
echo($Horario);
echo($Genero);
echo($Materias);
echo($Edad);



?>