﻿<?php

if(isset($_POST["num1"]) && isset($_POST["num2"]) && isset($_POST["op"]))
{
	require "funciones.php";

	$num1 = $_POST["num1"];
	$num2 = $_POST["num2"];
	$op = trim($_POST["op"]);
	if(!is_numeric($num1) || !is_numeric($num2))
	{
		$resultado = "Ingrese Números";
	} 
	else
	{
		$num1 = intval($num1, 10);
		$num2 = intval($num2, 10);
		switch ($op)
		{
			case "+": $resultado = Suma($num1, $num2); break;
			case "-": $resultado = Resta($num1, $num2); break;
			case "*": $resultado = Multiplica($num1, $num2); break;
			case "/":
				if($num2 != 0) {
					$resultado = Divide($num1, $num2);
				} else {
					$resultado = "Err. Div. Cero";
				}
				break;
			default: $resultado = "Seleccione Operación";
		}
	}

	/*Genera respuesta en JSON*/
	echo json_encode($resultado);

	exit();
}

?>