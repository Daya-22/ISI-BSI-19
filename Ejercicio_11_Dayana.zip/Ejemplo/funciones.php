<?php

function Suma($x, $y)
{
	return ($x + $y);
}

function Resta($x, $y)
{
	return ($x - $y);
}

function Multiplica($x, $y)
{
	return ($x * $y);
}

function Divide($x, $y)
{
	return ($x / $y);
}

?>